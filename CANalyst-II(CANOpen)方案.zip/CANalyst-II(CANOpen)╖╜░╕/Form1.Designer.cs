﻿namespace CANalyst_II_CANOpen_方案
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button_StopCAN = new System.Windows.Forms.Button();
            this.button_StartCAN = new System.Windows.Forms.Button();
            this.buttonConnect = new System.Windows.Forms.Button();
            this.comboBox_DevIndex = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox_CAN2 = new System.Windows.Forms.GroupBox();
            this.comboBox_Mode2 = new System.Windows.Forms.ComboBox();
            this.textBox2_Time1 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox2_Time0 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox_AccMask2 = new System.Windows.Forms.TextBox();
            this.comboBox_Filter2 = new System.Windows.Forms.ComboBox();
            this.textBox_AccCode2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox_CAN1 = new System.Windows.Forms.GroupBox();
            this.comboBox_Mode1 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBox_Filter1 = new System.Windows.Forms.ComboBox();
            this.textBox1_Time1 = new System.Windows.Forms.TextBox();
            this.textBox1_Time0 = new System.Windows.Forms.TextBox();
            this.textBox_AccMask1 = new System.Windows.Forms.TextBox();
            this.textBox_AccCode1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox_devtype = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBox_FrameFormat1 = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBox_FrameType1 = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.button_Send1 = new System.Windows.Forms.Button();
            this.textBox_ID1 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox_Data1 = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.comboBox_FrameFormat2 = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.comboBox_FrameType2 = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.button_Send2 = new System.Windows.Forms.Button();
            this.textBox_ID2 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox_Data2 = new System.Windows.Forms.TextBox();
            this.listBox_Info1 = new System.Windows.Forms.ListBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button_Clear1 = new System.Windows.Forms.Button();
            this.listBox_Info2 = new System.Windows.Forms.ListBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button_Clear2 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox_CAN2.SuspendLayout();
            this.groupBox_CAN1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button_StopCAN);
            this.groupBox1.Controls.Add(this.button_StartCAN);
            this.groupBox1.Controls.Add(this.buttonConnect);
            this.groupBox1.Controls.Add(this.comboBox_DevIndex);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.groupBox_CAN2);
            this.groupBox1.Controls.Add(this.groupBox_CAN1);
            this.groupBox1.Controls.Add(this.comboBox_devtype);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(842, 159);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "设备参数";
            // 
            // button_StopCAN
            // 
            this.button_StopCAN.Location = new System.Drawing.Point(738, 20);
            this.button_StopCAN.Name = "button_StopCAN";
            this.button_StopCAN.Size = new System.Drawing.Size(91, 29);
            this.button_StopCAN.TabIndex = 7;
            this.button_StopCAN.Text = "复位CAN";
            this.button_StopCAN.UseVisualStyleBackColor = true;
            this.button_StopCAN.Click += new System.EventHandler(this.button_StopCAN_Click);
            // 
            // button_StartCAN
            // 
            this.button_StartCAN.Location = new System.Drawing.Point(606, 20);
            this.button_StartCAN.Name = "button_StartCAN";
            this.button_StartCAN.Size = new System.Drawing.Size(89, 30);
            this.button_StartCAN.TabIndex = 8;
            this.button_StartCAN.Text = "启动CAN";
            this.button_StartCAN.UseVisualStyleBackColor = true;
            this.button_StartCAN.Click += new System.EventHandler(this.button_StartCAN_Click);
            // 
            // buttonConnect
            // 
            this.buttonConnect.Location = new System.Drawing.Point(466, 19);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new System.Drawing.Size(104, 30);
            this.buttonConnect.TabIndex = 6;
            this.buttonConnect.Text = "连接/初始化参数";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
            // 
            // comboBox_DevIndex
            // 
            this.comboBox_DevIndex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_DevIndex.FormattingEnabled = true;
            this.comboBox_DevIndex.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.comboBox_DevIndex.Location = new System.Drawing.Point(280, 25);
            this.comboBox_DevIndex.Name = "comboBox_DevIndex";
            this.comboBox_DevIndex.Size = new System.Drawing.Size(72, 20);
            this.comboBox_DevIndex.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(221, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "索引号：";
            // 
            // groupBox_CAN2
            // 
            this.groupBox_CAN2.Controls.Add(this.comboBox_Mode2);
            this.groupBox_CAN2.Controls.Add(this.textBox2_Time1);
            this.groupBox_CAN2.Controls.Add(this.label13);
            this.groupBox_CAN2.Controls.Add(this.textBox2_Time0);
            this.groupBox_CAN2.Controls.Add(this.label14);
            this.groupBox_CAN2.Controls.Add(this.textBox_AccMask2);
            this.groupBox_CAN2.Controls.Add(this.comboBox_Filter2);
            this.groupBox_CAN2.Controls.Add(this.textBox_AccCode2);
            this.groupBox_CAN2.Controls.Add(this.label7);
            this.groupBox_CAN2.Controls.Add(this.label8);
            this.groupBox_CAN2.Controls.Add(this.label9);
            this.groupBox_CAN2.Controls.Add(this.label10);
            this.groupBox_CAN2.Location = new System.Drawing.Point(418, 59);
            this.groupBox_CAN2.Name = "groupBox_CAN2";
            this.groupBox_CAN2.Size = new System.Drawing.Size(418, 91);
            this.groupBox_CAN2.TabIndex = 3;
            this.groupBox_CAN2.TabStop = false;
            this.groupBox_CAN2.Text = "第2路CAN初始化参数";
            // 
            // comboBox_Mode2
            // 
            this.comboBox_Mode2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Mode2.FormattingEnabled = true;
            this.comboBox_Mode2.Items.AddRange(new object[] {
            "正常",
            "只听",
            "自测"});
            this.comboBox_Mode2.Location = new System.Drawing.Point(341, 58);
            this.comboBox_Mode2.Name = "comboBox_Mode2";
            this.comboBox_Mode2.Size = new System.Drawing.Size(71, 20);
            this.comboBox_Mode2.TabIndex = 14;
            // 
            // textBox2_Time1
            // 
            this.textBox2_Time1.Location = new System.Drawing.Point(215, 58);
            this.textBox2_Time1.Name = "textBox2_Time1";
            this.textBox2_Time1.Size = new System.Drawing.Size(49, 21);
            this.textBox2_Time1.TabIndex = 15;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(294, 61);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 12);
            this.label13.TabIndex = 13;
            this.label13.Text = "模式：";
            // 
            // textBox2_Time0
            // 
            this.textBox2_Time0.Location = new System.Drawing.Point(215, 29);
            this.textBox2_Time0.Name = "textBox2_Time0";
            this.textBox2_Time0.Size = new System.Drawing.Size(49, 21);
            this.textBox2_Time0.TabIndex = 14;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(270, 31);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 12);
            this.label14.TabIndex = 12;
            this.label14.Text = "滤波方式：";
            // 
            // textBox_AccMask2
            // 
            this.textBox_AccMask2.Location = new System.Drawing.Point(85, 56);
            this.textBox_AccMask2.Name = "textBox_AccMask2";
            this.textBox_AccMask2.Size = new System.Drawing.Size(50, 21);
            this.textBox_AccMask2.TabIndex = 13;
            // 
            // comboBox_Filter2
            // 
            this.comboBox_Filter2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Filter2.FormattingEnabled = true;
            this.comboBox_Filter2.Items.AddRange(new object[] {
            "接收全部类型",
            "只接收标准帧",
            "只接收扩展帧"});
            this.comboBox_Filter2.Location = new System.Drawing.Point(341, 26);
            this.comboBox_Filter2.Name = "comboBox_Filter2";
            this.comboBox_Filter2.Size = new System.Drawing.Size(71, 20);
            this.comboBox_Filter2.TabIndex = 11;
            // 
            // textBox_AccCode2
            // 
            this.textBox_AccCode2.Location = new System.Drawing.Point(85, 29);
            this.textBox_AccCode2.Name = "textBox_AccCode2";
            this.textBox_AccCode2.Size = new System.Drawing.Size(50, 21);
            this.textBox_AccCode2.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(141, 60);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 12);
            this.label7.TabIndex = 11;
            this.label7.Text = "定时器1：0x";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(141, 32);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 12);
            this.label8.TabIndex = 10;
            this.label8.Text = "定时器0：0x";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 59);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 12);
            this.label9.TabIndex = 9;
            this.label9.Text = "屏蔽码：0x";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 32);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 12);
            this.label10.TabIndex = 8;
            this.label10.Text = "验收码：0x";
            // 
            // groupBox_CAN1
            // 
            this.groupBox_CAN1.Controls.Add(this.comboBox_Mode1);
            this.groupBox_CAN1.Controls.Add(this.label12);
            this.groupBox_CAN1.Controls.Add(this.label11);
            this.groupBox_CAN1.Controls.Add(this.comboBox_Filter1);
            this.groupBox_CAN1.Controls.Add(this.textBox1_Time1);
            this.groupBox_CAN1.Controls.Add(this.textBox1_Time0);
            this.groupBox_CAN1.Controls.Add(this.textBox_AccMask1);
            this.groupBox_CAN1.Controls.Add(this.textBox_AccCode1);
            this.groupBox_CAN1.Controls.Add(this.label6);
            this.groupBox_CAN1.Controls.Add(this.label5);
            this.groupBox_CAN1.Controls.Add(this.label4);
            this.groupBox_CAN1.Controls.Add(this.label3);
            this.groupBox_CAN1.Location = new System.Drawing.Point(6, 59);
            this.groupBox_CAN1.Name = "groupBox_CAN1";
            this.groupBox_CAN1.Size = new System.Drawing.Size(406, 91);
            this.groupBox_CAN1.TabIndex = 2;
            this.groupBox_CAN1.TabStop = false;
            this.groupBox_CAN1.Text = "第1路CAN初始化参数";
            // 
            // comboBox_Mode1
            // 
            this.comboBox_Mode1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Mode1.FormattingEnabled = true;
            this.comboBox_Mode1.Items.AddRange(new object[] {
            "正常",
            "只听",
            "自测"});
            this.comboBox_Mode1.Location = new System.Drawing.Point(319, 58);
            this.comboBox_Mode1.Name = "comboBox_Mode1";
            this.comboBox_Mode1.Size = new System.Drawing.Size(71, 20);
            this.comboBox_Mode1.TabIndex = 10;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(272, 59);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 12);
            this.label12.TabIndex = 9;
            this.label12.Text = "模式：";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(252, 29);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 12);
            this.label11.TabIndex = 8;
            this.label11.Text = "滤波方式：";
            // 
            // comboBox_Filter1
            // 
            this.comboBox_Filter1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Filter1.FormattingEnabled = true;
            this.comboBox_Filter1.Items.AddRange(new object[] {
            "接收全部类型",
            "只接收标准帧",
            "只接收扩展帧"});
            this.comboBox_Filter1.Location = new System.Drawing.Point(319, 28);
            this.comboBox_Filter1.Name = "comboBox_Filter1";
            this.comboBox_Filter1.Size = new System.Drawing.Size(71, 20);
            this.comboBox_Filter1.TabIndex = 7;
            // 
            // textBox1_Time1
            // 
            this.textBox1_Time1.Location = new System.Drawing.Point(198, 54);
            this.textBox1_Time1.Name = "textBox1_Time1";
            this.textBox1_Time1.Size = new System.Drawing.Size(48, 21);
            this.textBox1_Time1.TabIndex = 7;
            // 
            // textBox1_Time0
            // 
            this.textBox1_Time0.Location = new System.Drawing.Point(198, 27);
            this.textBox1_Time0.Name = "textBox1_Time0";
            this.textBox1_Time0.Size = new System.Drawing.Size(48, 21);
            this.textBox1_Time0.TabIndex = 6;
            // 
            // textBox_AccMask1
            // 
            this.textBox_AccMask1.Location = new System.Drawing.Point(71, 54);
            this.textBox_AccMask1.Name = "textBox_AccMask1";
            this.textBox_AccMask1.Size = new System.Drawing.Size(47, 21);
            this.textBox_AccMask1.TabIndex = 5;
            // 
            // textBox_AccCode1
            // 
            this.textBox_AccCode1.Location = new System.Drawing.Point(71, 27);
            this.textBox_AccCode1.Name = "textBox_AccCode1";
            this.textBox_AccCode1.Size = new System.Drawing.Size(47, 21);
            this.textBox_AccCode1.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(124, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 12);
            this.label6.TabIndex = 3;
            this.label6.Text = "定时器1：0x";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(121, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 12);
            this.label5.TabIndex = 2;
            this.label5.Text = "定时器0：0x";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 58);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 1;
            this.label4.Text = "屏蔽码：0x";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "验收码：0x";
            // 
            // comboBox_devtype
            // 
            this.comboBox_devtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_devtype.FormattingEnabled = true;
            this.comboBox_devtype.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.comboBox_devtype.Items.AddRange(new object[] {
            "3",
            "4"});
            this.comboBox_devtype.Location = new System.Drawing.Point(77, 25);
            this.comboBox_devtype.Name = "comboBox_devtype";
            this.comboBox_devtype.Size = new System.Drawing.Size(121, 20);
            this.comboBox_devtype.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "设备类型：";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comboBox_FrameFormat1);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.comboBox_FrameType1);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.button_Send1);
            this.groupBox2.Controls.Add(this.textBox_ID1);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.textBox_Data1);
            this.groupBox2.Location = new System.Drawing.Point(12, 176);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(411, 84);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "CAN1发送数据";
            // 
            // comboBox_FrameFormat1
            // 
            this.comboBox_FrameFormat1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_FrameFormat1.FormattingEnabled = true;
            this.comboBox_FrameFormat1.Items.AddRange(new object[] {
            "数据帧",
            "远程帧"});
            this.comboBox_FrameFormat1.Location = new System.Drawing.Point(187, 21);
            this.comboBox_FrameFormat1.Name = "comboBox_FrameFormat1";
            this.comboBox_FrameFormat1.Size = new System.Drawing.Size(70, 20);
            this.comboBox_FrameFormat1.TabIndex = 10;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(11, 26);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(47, 12);
            this.label16.TabIndex = 7;
            this.label16.Text = "帧类型:";
            // 
            // comboBox_FrameType1
            // 
            this.comboBox_FrameType1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_FrameType1.FormattingEnabled = true;
            this.comboBox_FrameType1.Items.AddRange(new object[] {
            "标准帧",
            "扩展帧"});
            this.comboBox_FrameType1.Location = new System.Drawing.Point(60, 22);
            this.comboBox_FrameType1.Name = "comboBox_FrameType1";
            this.comboBox_FrameType1.Size = new System.Drawing.Size(70, 20);
            this.comboBox_FrameType1.TabIndex = 11;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(263, 26);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(47, 12);
            this.label18.TabIndex = 9;
            this.label18.Text = "帧ID:0x";
            // 
            // button_Send1
            // 
            this.button_Send1.Location = new System.Drawing.Point(316, 49);
            this.button_Send1.Name = "button_Send1";
            this.button_Send1.Size = new System.Drawing.Size(75, 23);
            this.button_Send1.TabIndex = 14;
            this.button_Send1.Text = "发送1";
            this.button_Send1.UseVisualStyleBackColor = true;
            this.button_Send1.Click += new System.EventHandler(this.button_Send1_Click);
            // 
            // textBox_ID1
            // 
            this.textBox_ID1.Location = new System.Drawing.Point(313, 20);
            this.textBox_ID1.Name = "textBox_ID1";
            this.textBox_ID1.Size = new System.Drawing.Size(70, 21);
            this.textBox_ID1.TabIndex = 13;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(138, 25);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 12);
            this.label15.TabIndex = 6;
            this.label15.Text = "帧格式:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(10, 56);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 12);
            this.label17.TabIndex = 8;
            this.label17.Text = "数据:";
            // 
            // textBox_Data1
            // 
            this.textBox_Data1.Location = new System.Drawing.Point(47, 50);
            this.textBox_Data1.Name = "textBox_Data1";
            this.textBox_Data1.Size = new System.Drawing.Size(251, 21);
            this.textBox_Data1.TabIndex = 12;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.comboBox_FrameFormat2);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.comboBox_FrameType2);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.button_Send2);
            this.groupBox3.Controls.Add(this.textBox_ID2);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.textBox_Data2);
            this.groupBox3.Location = new System.Drawing.Point(431, 177);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(411, 84);
            this.groupBox3.TabIndex = 15;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "CAN2发送数据";
            // 
            // comboBox_FrameFormat2
            // 
            this.comboBox_FrameFormat2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_FrameFormat2.FormattingEnabled = true;
            this.comboBox_FrameFormat2.Items.AddRange(new object[] {
            "数据帧",
            "远程帧"});
            this.comboBox_FrameFormat2.Location = new System.Drawing.Point(187, 21);
            this.comboBox_FrameFormat2.Name = "comboBox_FrameFormat2";
            this.comboBox_FrameFormat2.Size = new System.Drawing.Size(70, 20);
            this.comboBox_FrameFormat2.TabIndex = 10;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(11, 26);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(47, 12);
            this.label19.TabIndex = 7;
            this.label19.Text = "帧类型:";
            // 
            // comboBox_FrameType2
            // 
            this.comboBox_FrameType2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_FrameType2.FormattingEnabled = true;
            this.comboBox_FrameType2.Items.AddRange(new object[] {
            "标准帧",
            "扩展帧"});
            this.comboBox_FrameType2.Location = new System.Drawing.Point(60, 22);
            this.comboBox_FrameType2.Name = "comboBox_FrameType2";
            this.comboBox_FrameType2.Size = new System.Drawing.Size(70, 20);
            this.comboBox_FrameType2.TabIndex = 11;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(263, 26);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(47, 12);
            this.label20.TabIndex = 9;
            this.label20.Text = "帧ID:0x";
            // 
            // button_Send2
            // 
            this.button_Send2.Location = new System.Drawing.Point(316, 49);
            this.button_Send2.Name = "button_Send2";
            this.button_Send2.Size = new System.Drawing.Size(75, 23);
            this.button_Send2.TabIndex = 14;
            this.button_Send2.Text = "发送2";
            this.button_Send2.UseVisualStyleBackColor = true;
            this.button_Send2.Click += new System.EventHandler(this.button_Send2_Click);
            // 
            // textBox_ID2
            // 
            this.textBox_ID2.Location = new System.Drawing.Point(313, 20);
            this.textBox_ID2.Name = "textBox_ID2";
            this.textBox_ID2.Size = new System.Drawing.Size(70, 21);
            this.textBox_ID2.TabIndex = 13;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(138, 25);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(47, 12);
            this.label21.TabIndex = 6;
            this.label21.Text = "帧格式:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(10, 56);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(35, 12);
            this.label22.TabIndex = 8;
            this.label22.Text = "数据:";
            // 
            // textBox_Data2
            // 
            this.textBox_Data2.Location = new System.Drawing.Point(47, 50);
            this.textBox_Data2.Name = "textBox_Data2";
            this.textBox_Data2.Size = new System.Drawing.Size(251, 21);
            this.textBox_Data2.TabIndex = 12;
            // 
            // listBox_Info1
            // 
            this.listBox_Info1.FormattingEnabled = true;
            this.listBox_Info1.HorizontalScrollbar = true;
            this.listBox_Info1.ItemHeight = 12;
            this.listBox_Info1.Location = new System.Drawing.Point(10, 20);
            this.listBox_Info1.Name = "listBox_Info1";
            this.listBox_Info1.Size = new System.Drawing.Size(381, 220);
            this.listBox_Info1.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button_Clear1);
            this.groupBox4.Controls.Add(this.listBox_Info1);
            this.groupBox4.Location = new System.Drawing.Point(13, 266);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(411, 246);
            this.groupBox4.TabIndex = 16;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "CAN1信息";
            // 
            // button_Clear1
            // 
            this.button_Clear1.Location = new System.Drawing.Point(289, 0);
            this.button_Clear1.Name = "button_Clear1";
            this.button_Clear1.Size = new System.Drawing.Size(101, 22);
            this.button_Clear1.TabIndex = 9;
            this.button_Clear1.Text = "清空列表1";
            this.button_Clear1.UseVisualStyleBackColor = true;
            this.button_Clear1.Click += new System.EventHandler(this.button_Clear1_Click);
            // 
            // listBox_Info2
            // 
            this.listBox_Info2.FormattingEnabled = true;
            this.listBox_Info2.HorizontalScrollbar = true;
            this.listBox_Info2.ItemHeight = 12;
            this.listBox_Info2.Location = new System.Drawing.Point(10, 20);
            this.listBox_Info2.Name = "listBox_Info2";
            this.listBox_Info2.Size = new System.Drawing.Size(381, 220);
            this.listBox_Info2.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button_Clear2);
            this.groupBox5.Controls.Add(this.listBox_Info2);
            this.groupBox5.Location = new System.Drawing.Point(430, 267);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(411, 245);
            this.groupBox5.TabIndex = 17;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "CAN2信息";
            // 
            // button_Clear2
            // 
            this.button_Clear2.Location = new System.Drawing.Point(290, 0);
            this.button_Clear2.Name = "button_Clear2";
            this.button_Clear2.Size = new System.Drawing.Size(101, 22);
            this.button_Clear2.TabIndex = 10;
            this.button_Clear2.Text = "清空列表2";
            this.button_Clear2.UseVisualStyleBackColor = true;
            this.button_Clear2.Click += new System.EventHandler(this.button_Clear2_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(866, 517);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "CANalyst-I/II(双路)测试程序";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox_CAN2.ResumeLayout(false);
            this.groupBox_CAN2.PerformLayout();
            this.groupBox_CAN1.ResumeLayout(false);
            this.groupBox_CAN1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox_devtype;
        private System.Windows.Forms.GroupBox groupBox_CAN2;
        private System.Windows.Forms.GroupBox groupBox_CAN1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox_DevIndex;
        private System.Windows.Forms.Button buttonConnect;
        private System.Windows.Forms.TextBox textBox2_Time1;
        private System.Windows.Forms.TextBox textBox2_Time0;
        private System.Windows.Forms.TextBox textBox_AccMask2;
        private System.Windows.Forms.TextBox textBox_AccCode2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox1_Time1;
        private System.Windows.Forms.TextBox textBox1_Time0;
        private System.Windows.Forms.TextBox textBox_AccMask1;
        private System.Windows.Forms.TextBox textBox_AccCode1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox_Mode2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboBox_Filter2;
        private System.Windows.Forms.ComboBox comboBox_Mode1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBox_Filter1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboBox_FrameFormat1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox comboBox_FrameType1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button_Send1;
        private System.Windows.Forms.TextBox textBox_ID1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox_Data1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox comboBox_FrameFormat2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox comboBox_FrameType2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button_Send2;
        private System.Windows.Forms.TextBox textBox_ID2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox_Data2;
        private System.Windows.Forms.ListBox listBox_Info1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ListBox listBox_Info2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button_StopCAN;
        private System.Windows.Forms.Button button_StartCAN;
        private System.Windows.Forms.Button button_Clear1;
        private System.Windows.Forms.Button button_Clear2;
        private System.Windows.Forms.Timer timer1;
    }
}

