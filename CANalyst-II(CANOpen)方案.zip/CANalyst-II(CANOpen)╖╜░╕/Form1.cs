﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;//需要用到这个命名空间

/*------------兼容ZLG的数据类型---------------------------------*/

//1.ZLGCAN系列接口卡信息的数据类型。
public struct VCI_BOARD_INFO//(第一个)
{
    public UInt16 hw_Version;   //申明hw_Version：硬件版本号，用16进制表示。比如0x0100表示V1.00。
    public UInt16 fw_Version;   //申明fw_Version：固件版本号，用16进制表示。比如0x0100表示V1.00。
    public UInt16 dr_Version;   //申明dr_Version：驱动程序版本号，用16进制表示。比如0x0100表示V1.00。
    public UInt16 in_Version;   //申明dr_Version：接口库版本号，用16进制表示。比如0x0100表示V1.00。
    public UInt16 irq_Num;      //申明irq_Num：保留参数。
    public byte can_Num;        //申明can_Num：表示有几路CAN通道。
    /*
     str_Serial_Num此板卡的序列号。
     str_hw_Type硬件类型，比如“USBCAN V1.00”（注意：包括字符串结束符’\0’）
     Reserved系统保留。
     */
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)] public byte[] str_Serial_Num;//二维数组转一维数组
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 40)] public byte[] str_hw_Type;//二维数组转一维数组
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)] public byte[] Reserved;//二维数组转一维数组
    /*
    作用：
    MarshalAs属性指示如何在托管代码和非托管代码之间封送数据。
    使用方法：
    [MarshalAs(UnmanagedType unmanagedType, 命名参数)]
    实际上相当于构造一个MarshalAsAttribute类的对象
     */
}

/////////////////////////////////////////////////////
//2.定义CAN信息帧的数据类型。
unsafe public struct VCI_CAN_OBJ  //使用不安全代码
{
    public uint ID;
    public uint TimeStamp;        //时间标识
    public byte TimeFlag;         //是否使用时间标识
    public byte SendType;         //发送标志。保留，未用
    public byte RemoteFlag;       //是否是远程帧
    public byte ExternFlag;       //是否是扩展帧
    public byte DataLen;          //数据长度
    public fixed byte Data[8];    //数据
    public fixed byte Reserved[3];//保留位
}

//3.定义初始化CAN的数据类型
public struct VCI_INIT_CONFIG
{
    public UInt32 AccCode;//验收码。SJA1000的帧过滤验收码。对经过屏蔽码过滤为“有关位”进行匹配，全部匹配成功后，此帧可以被接收。否则不接收。详见VCI_InitCAN。
    public UInt32 AccMask;//屏蔽码。SJA1000的帧过滤屏蔽码。对接收的CAN帧ID进行过滤，对应位为0的是“有关位”，对应位为1的是“无关位”。屏蔽码推荐设置为0xFFFFFFFF，即全部接收。
    public UInt32 Reserved;//保留。
    public byte Filter;   //0或1接收所有帧。2标准帧滤波，3是扩展帧滤波。
    public byte Timing0;  //波特率参数，具体配置，请查看二次开发库函数说明书。
    public byte Timing1;
    /* 
   CAN波特率 Timing0(BTR0)  Timing1(BTR1)
   10 Kbps        0x31         0x1C
   20 Kbps        0x18         0x1C
   40 Kbps        0x87         0xFF
   50 Kbps        0x09         0x1C
   80 Kbps        0x83         0xFF
  100 Kbps        0x04         0x1C
  125 Kbps        0x03         0x1C
  200 Kbps        0x81         0xFA
  250 Kbps        0x01         0x1C
  400 Kbps        0x80         0xFA
  500 Kbps        0x00         0x1C
  666 Kbps        0x80         0xB6
  800 Kbps        0x00         0x16
 1000 Kbps        0x00         0x14
 33.33 Kbps       0x09         0x6F
 66.66 Kbps       0x04         0x6F
 83.33 Kbps       0x03         0x6F
 */
    public byte Mode;     //模式，0表示正常模式，1表示只听模式,2自测模式
}

/*------------其他数据结构描述---------------------------------*/
//4.USB-CAN总线适配器板卡信息的数据类型1，该类型为VCI_FindUsbDevice函数的返回参数。
public struct VCI_BOARD_INFO1//(第二个)
{
    public UInt16 hw_Version;//申明hw_Version：硬件版本号，用16进制表示。
    public UInt16 fw_Version;//申明fw_Version：固件版本号，用16进制表示。
    public UInt16 dr_Version;//申明dr_Version：驱动程序版本号，用16进制表示。
    public UInt16 in_Version;//申明dr_Version：接口库版本号，用16进制表示。
    public UInt16 irq_Num; //申明irq_Num：保留参数。
    public byte can_Num; //申明can_Num：表示有几路CAN通道。
    public byte Reserved;//Reserved系统保留。
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)] public byte[] str_Serial_Num;//二维数组转一维数组
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)] public byte[] str_hw_Type;//二维数组转一维数组
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)] public byte[] str_Usb_Serial;//两个CAN卡同一台电脑使用，调用VCI_FindUsbDevice(ref VCI_BOARD_INFO1 pInfo)函数，函数返回值为2。结构体中，str_Usb_Serial前4字节为卡1的序列号，后4字节为卡2的序列号。
}

/*------------数据结构描述完成---------------------------------*/

/*CHGDESIPANDPORT 结构体用于装载更改 CANET_UDP 与 CANET_TCP 的目标 IP 和
端口的必要信息。此结构体在 CANETE_UDP 与 CANET_TCP 中使用。
typedef struct _tagChgDesIPAndPort {
char szpwd[10];     //更改目标 IP 和端口所需要的密码
char szdesip[20];   //所要更改的目标 IP
int desport;        //所要更改的目标端口，比如为 4000。
BYTE blisten;       //所要更改的工作模式，0 表示正常模式，1 表示只听模式。
} CHGDESIPANDPORT;*/
public struct CHGDESIPANDPORT   //CANET 通讯结构体
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)] public byte[] szpwd;//转一维数组（10位），更改目标 IP 和端口所需要的密码，长度小于 10，比如为“11223344”。
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)] public byte[] szdesip;//转一维数组（20位），所要更改的目标 IP，比如为“192.168.0.111”。
    public Int32 desport;

    public void Init()
    {
        szpwd = new byte[10];
        szdesip = new byte[20];
    }
}

namespace CANalyst_II_CANOpen_方案    //方案空间(类似主函数)
{
    public partial class Form1 : Form   //部分类Form1
    {
        /*------------------------------------------------------------------------------*/
        const int DEV_USBCAN = 3;   //全局变量定义，这里USBCANalyst-I为3
        const int DEV_USBCAN2 = 4;  //全局变量定义，这里USBCANalyst-II为4
        int flag_can = 1;//定义一个标志，1的时候接收2通道，2的时候接收1通道(全局变量属性)
        /// <summary>
        /// 
        /// </summary>
        /// <param name="DeviceType"></param>
        /// <param name="DeviceInd"></param>
        /// <param name="Reserved"></param>
        /// <returns></returns>
        /*------------兼容ZLG的函数描述---------------------------------*/
        [DllImport("controlcan.dll")]
        static extern UInt32 VCI_OpenDevice(UInt32 DeviceType, UInt32 DeviceInd, UInt32 Reserved);
        [DllImport("controlcan.dll")]
        static extern UInt32 VCI_CloseDevice(UInt32 DeviceType, UInt32 DeviceInd);
        [DllImport("controlcan.dll")]
        static extern UInt32 VCI_InitCAN(UInt32 DeviceType, UInt32 DeviceInd, UInt32 CANInd, ref VCI_INIT_CONFIG pInitConfig);

        [DllImport("controlcan.dll")]
        static extern UInt32 VCI_ReadBoardInfo(UInt32 DeviceType, UInt32 DeviceInd, ref VCI_BOARD_INFO pInfo);

        [DllImport("controlcan.dll")]
        static extern UInt32 VCI_GetReceiveNum(UInt32 DeviceType, UInt32 DeviceInd, UInt32 CANInd);
        [DllImport("controlcan.dll")]
        static extern UInt32 VCI_ClearBuffer(UInt32 DeviceType, UInt32 DeviceInd, UInt32 CANInd);

        [DllImport("controlcan.dll")]
        static extern UInt32 VCI_StartCAN(UInt32 DeviceType, UInt32 DeviceInd, UInt32 CANInd);
        [DllImport("controlcan.dll")]
        static extern UInt32 VCI_ResetCAN(UInt32 DeviceType, UInt32 DeviceInd, UInt32 CANInd);

        [DllImport("controlcan.dll")]
        static extern UInt32 VCI_Transmit(UInt32 DeviceType, UInt32 DeviceInd, UInt32 CANInd, ref VCI_CAN_OBJ pSend, UInt32 Len);

        [DllImport("controlcan.dll")]
        static extern UInt32 VCI_Receive(UInt32 DeviceType, UInt32 DeviceInd, UInt32 CANInd, ref VCI_CAN_OBJ pReceive, UInt32 Len, Int32 WaitTime);

        /*------------其他函数描述---------------------------------*/

        [DllImport("controlcan.dll")]
        static extern UInt32 VCI_ConnectDevice(UInt32 DevType, UInt32 DevIndex);
        [DllImport("controlcan.dll")]
        static extern UInt32 VCI_UsbDeviceReset(UInt32 DevType, UInt32 DevIndex, UInt32 Reserved);
        [DllImport("controlcan.dll")]
        static extern UInt32 VCI_FindUsbDevice(ref VCI_BOARD_INFO1 pInfo);
        /*------------函数描述结束---------------------------------*/

        static UInt32 m_devtype = 4;//USBCAN2，默认初始自动选择CANalyst-II(在后面下拉菜单的时候会用到)

        UInt32 m_bOpen = 0;     //开启按钮-状态断开
        UInt32 m_devind = 0;    //索引号：默认状态第0个，PC端只插入一个CAN设备时均为0索引，插入多个同型号的CAN时索引号自动分配0，1,2.....
        //UInt32 m_canind = 0;    //第几路CAN：一个CAN盒子中有多路CAN时选择，0表示第一路，1表示第二路，以此类推
        UInt32 m_canind1 = 0, m_canind2 = 1;

        VCI_CAN_OBJ[] m_recobj1 = new VCI_CAN_OBJ[1000]; //帧结构体 VCI_CAN_OBJ 数组
        VCI_CAN_OBJ[] m_recobj2 = new VCI_CAN_OBJ[1000]; //帧结构体 VCI_CAN_OBJ2 数组

        UInt32[] m_arrdevtype = new UInt32[20];//定义字段m_arrdevtype,20位一维数组，用于存放设备类型comboBox_devtype菜单中的项目的值
        /*------------------------------------------------------------------------------*/

        public Form1()
        {
            InitializeComponent();
        }

        //窗口开启时进行的操作（各种参数初始化）
        private void Form1_Load(object sender, EventArgs e)
        {
            //窗口中的各种控件的初始值设定
            //----------------1、2CAN公用参数部分--------------
            comboBox_DevIndex.SelectedIndex = 0;//索引号选择
            //-------------------------------------------------
            //第一路CAN
            textBox_AccCode1.Text = "00000000";
            textBox_AccMask1.Text = "FFFFFFFF";
            textBox1_Time0.Text = "00";
            textBox1_Time1.Text = "1C";
            comboBox_Filter1.SelectedIndex = 0;              //接收所有类型
            comboBox_Mode1.SelectedIndex = 2;                //还回测试模式
            comboBox_FrameFormat1.SelectedIndex = 0;
            comboBox_FrameType1.SelectedIndex = 0;
            textBox_ID1.Text = "00000123";
            textBox_Data1.Text = "00 01 02 03 04 05 06 07 ";
            //第二路CAN
            textBox_AccCode2.Text = "00000000";
            textBox_AccMask2.Text = "FFFFFFFF";
            textBox2_Time0.Text = "00";
            textBox2_Time1.Text = "1C";
            comboBox_Filter2.SelectedIndex = 0;              //接收所有类型
            comboBox_Mode2.SelectedIndex = 2;                //还回测试模式
            comboBox_FrameFormat2.SelectedIndex = 0;
            comboBox_FrameType2.SelectedIndex = 0;
            textBox_ID2.Text = "00000123";
            textBox_Data2.Text = "00 01 02 03 04 05 06 07 ";

            //设备类型选择菜单comboBox_devtype的设置部分
            Int32 curindex = 0; //定义变量
            comboBox_devtype.Items.Clear();//清空comboBox所有填充的items。
            /*listview.clear()与listview.item.clear()的区别就是使用了listview.item.clear()后，listview控件中仍然保存着listviewitem项的结构，即listview有多个列，每列可能对应的列标题数据等。而当你使用了listview.clear()后，整个listview内保存数据的结构就没了。*/

            curindex = comboBox_devtype.Items.Add("CANalyst-I");//添加项目DEV_USBCAN
            m_arrdevtype[curindex] = DEV_USBCAN;
            //comboBox_devtype.Items[2] = "VCI_USBCAN1";
            //m_arrdevtype[2]=  VCI_USBCAN1 ;

            curindex = comboBox_devtype.Items.Add("CANalyst-II");//添加项目DEV_USBCAN2
            m_arrdevtype[curindex] = DEV_USBCAN2;
            //comboBox_devtype.Items[3] = "VCI_USBCAN2";
            //m_arrdevtype[3]=  VCI_USBCAN2 ;

            comboBox_devtype.SelectedIndex = 1; //选择菜单默认选择第二项
            comboBox_devtype.MaxDropDownItems = comboBox_devtype.Items.Count;//获取或设置要在 ComboBox 的下拉部分中显示的最大项数。
        }
        
        //窗口关闭时进行的操作（进行CAN盒子的关闭操作)
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (m_bOpen == 1)//如果开启状态值显示1表示开启，则进行下面的关闭操作
            {
                VCI_CloseDevice(m_devtype, m_devind);//源于controlcan.dll，VCI关闭操作
            }
        }
        
        //“连接/初始化”按钮按下执行的操作
        private void buttonConnect_Click(object sender, EventArgs e)
        {
            if (m_bOpen == 1)//如果设备开启的，先执行关闭
            {
                VCI_CloseDevice(m_devtype, m_devind);
                m_bOpen = 0;
            }
            else//如果设备处于关闭状态
            {
                m_devtype = m_arrdevtype[comboBox_devtype.SelectedIndex];//选择类型

                m_devind = (UInt32)comboBox_DevIndex.SelectedIndex;//选择索引号
                if (VCI_OpenDevice(m_devtype, m_devind, 0) == 0)//判定连接函数
                {
                    MessageBox.Show("打开设备失败,请检查设备类型和设备索引号是否正确", "错误",
                            MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                m_bOpen = 1;//状态设为1表示开启设备
                VCI_INIT_CONFIG config = new VCI_INIT_CONFIG();
                VCI_INIT_CONFIG config2 = new VCI_INIT_CONFIG();
                //以下装入初始化的初值(第1路CAN)
                config.AccCode = System.Convert.ToUInt32("0x" + textBox_AccCode1.Text, 16);//验收码
                config.AccMask = System.Convert.ToUInt32("0x" + textBox_AccMask1.Text, 16);//屏蔽码
                config.Timing0 = System.Convert.ToByte("0x" + textBox1_Time0.Text, 16);//定时器0（设置波特率）
                config.Timing1 = System.Convert.ToByte("0x" + textBox1_Time1.Text, 16);//定时器1（设置波特率）
                config.Filter = (Byte)(comboBox_Filter1.SelectedIndex + 1);//滤波方式设置
                config.Mode = (Byte)comboBox_Mode1.SelectedIndex;//工作模式设置
                VCI_InitCAN(m_devtype, m_devind, m_canind1, ref config);//初始化第1路CAN

                //以下装入初始化的初值(第2路CAN)
                config2.AccCode = System.Convert.ToUInt32("0x" + textBox_AccCode2.Text, 16);//验收码
                config2.AccMask = System.Convert.ToUInt32("0x" + textBox_AccMask2.Text, 16);//屏蔽码
                config2.Timing0 = System.Convert.ToByte("0x" + textBox2_Time0.Text, 16);//定时器0（设置波特率）
                config2.Timing1 = System.Convert.ToByte("0x" + textBox2_Time1.Text, 16);//定时器1（设置波特率）
                config2.Filter = (Byte)(comboBox_Filter2.SelectedIndex + 1);//滤波方式设置
                config2.Mode = (Byte)comboBox_Mode2.SelectedIndex;//工作模式设置
                VCI_InitCAN(m_devtype, m_devind, m_canind2, ref config2);//初始化第2路CAN
            }
            buttonConnect.Text = m_bOpen == 1 ? "断开" : "连接/初始化参数";//改变连接按钮显示
            timer1.Enabled = m_bOpen == 1 ? true : false;//定时器使能操作
        }

        //启动CAN按钮操作
        private void button_StartCAN_Click(object sender, EventArgs e)
        {
            if (m_bOpen == 0)
                return;
            VCI_StartCAN(m_devtype, m_devind, m_canind1);
            VCI_StartCAN(m_devtype, m_devind, m_canind2);
        }

        //复位CAN按钮操作
        private void button_StopCAN_Click(object sender, EventArgs e)
        {
            if (m_bOpen == 0)
                return;
            VCI_ResetCAN(m_devtype, m_devind, m_canind1);
            VCI_ResetCAN(m_devtype, m_devind, m_canind2);
        }

        //CAN1发送按钮操作,注意！允许不安全代码
        unsafe private void button_Send1_Click(object sender, EventArgs e)
        {
            if (m_bOpen == 0)
                return;

            VCI_CAN_OBJ sendobj1 = new VCI_CAN_OBJ();//定义结构体
            //sendobj.Init();
            sendobj1.RemoteFlag = (byte)comboBox_FrameFormat1.SelectedIndex;
            sendobj1.ExternFlag = (byte)comboBox_FrameType1.SelectedIndex;
            sendobj1.ID = System.Convert.ToUInt32("0x" + textBox_ID1.Text, 16);
            int len = (textBox_Data1.Text.Length + 1) / 3;
            sendobj1.DataLen = System.Convert.ToByte(len);
            String strdata = textBox_Data1.Text;
            int i = -1;
            if (i++ < len - 1)
                sendobj1.Data[0] = System.Convert.ToByte("0x" + strdata.Substring(i * 3, 2), 16);
            if (i++ < len - 1)
                sendobj1.Data[1] = System.Convert.ToByte("0x" + strdata.Substring(i * 3, 2), 16);
            if (i++ < len - 1)
                sendobj1.Data[2] = System.Convert.ToByte("0x" + strdata.Substring(i * 3, 2), 16);
            if (i++ < len - 1)
                sendobj1.Data[3] = System.Convert.ToByte("0x" + strdata.Substring(i * 3, 2), 16);
            if (i++ < len - 1)
                sendobj1.Data[4] = System.Convert.ToByte("0x" + strdata.Substring(i * 3, 2), 16);
            if (i++ < len - 1)
                sendobj1.Data[5] = System.Convert.ToByte("0x" + strdata.Substring(i * 3, 2), 16);
            if (i++ < len - 1)
                sendobj1.Data[6] = System.Convert.ToByte("0x" + strdata.Substring(i * 3, 2), 16);
            if (i++ < len - 1)
                sendobj1.Data[7] = System.Convert.ToByte("0x" + strdata.Substring(i * 3, 2), 16);

            if (VCI_Transmit(m_devtype, m_devind, m_canind1, ref sendobj1, 1) == 0)
            {
                MessageBox.Show("发送失败", "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        //CAN2发送按钮操作,注意！允许不安全代码
        unsafe private void button_Send2_Click(object sender, EventArgs e)
        {
            if (m_bOpen == 0)
                return;

            VCI_CAN_OBJ sendobj2 = new VCI_CAN_OBJ();
            //sendobj.Init();
            sendobj2.RemoteFlag = (byte)comboBox_FrameFormat2.SelectedIndex;
            sendobj2.ExternFlag = (byte)comboBox_FrameType2.SelectedIndex;
            sendobj2.ID = System.Convert.ToUInt32("0x" + textBox_ID2.Text, 16);
            int len = (textBox_Data2.Text.Length + 1) / 3;
            sendobj2.DataLen = System.Convert.ToByte(len);
            String strdata = textBox_Data2.Text;
            int i = -1;
            if (i++ < len - 1)
                sendobj2.Data[0] = System.Convert.ToByte("0x" + strdata.Substring(i * 3, 2), 16);
            if (i++ < len - 1)
                sendobj2.Data[1] = System.Convert.ToByte("0x" + strdata.Substring(i * 3, 2), 16);
            if (i++ < len - 1)
                sendobj2.Data[2] = System.Convert.ToByte("0x" + strdata.Substring(i * 3, 2), 16);
            if (i++ < len - 1)
                sendobj2.Data[3] = System.Convert.ToByte("0x" + strdata.Substring(i * 3, 2), 16);
            if (i++ < len - 1)
                sendobj2.Data[4] = System.Convert.ToByte("0x" + strdata.Substring(i * 3, 2), 16);
            if (i++ < len - 1)
                sendobj2.Data[5] = System.Convert.ToByte("0x" + strdata.Substring(i * 3, 2), 16);
            if (i++ < len - 1)
                sendobj2.Data[6] = System.Convert.ToByte("0x" + strdata.Substring(i * 3, 2), 16);
            if (i++ < len - 1)
                sendobj2.Data[7] = System.Convert.ToByte("0x" + strdata.Substring(i * 3, 2), 16);

            if (VCI_Transmit(m_devtype, m_devind, m_canind2, ref sendobj2, 1) == 0)
            {
                MessageBox.Show("发送失败", "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        //信息窗口1清屏
        private void button_Clear1_Click(object sender, EventArgs e)
        {
            listBox_Info1.Items.Clear();
        }
        //信息窗口2清屏
        private void button_Clear2_Click(object sender, EventArgs e)
        {
            listBox_Info2.Items.Clear();
        }

        //定时器操作部分，触发周期：50ms，注意！！！使用不安全代码允许unsafe
        unsafe private void timer1_Tick(object sender, EventArgs e)
        {
            UInt32 res2 = new UInt32();
            UInt32 res1 = new UInt32();

            String str2 = "";
            String str = "";

            //---------------------------------------------------------------------------------------
            if (flag_can == 1)
            {
                res2 = VCI_Receive(m_devtype, m_devind, m_canind2, ref m_recobj2[0], 1000, 100);//第2路CAN的接收函数
                for (UInt32 i = 0; i < res2; i++)
                {
                    //VCI_CAN_OBJ obj = (VCI_CAN_OBJ)Marshal.PtrToStructure((IntPtr)((UInt32)pt + i * Marshal.SizeOf(typeof(VCI_CAN_OBJ))), typeof(VCI_CAN_OBJ));

                    str2 = "接收到数据: ";
                    str2 += "  帧ID:0x" + System.Convert.ToString(m_recobj2[i].ID, 16);
                    str2 += "  帧格式:";
                    if (m_recobj1[i].RemoteFlag == 0)
                        str2 += "数据帧 ";
                    else
                        str2 += "远程帧 ";
                    if (m_recobj1[i].ExternFlag == 0)
                        str2 += "标准帧 ";
                    else
                        str2 += "扩展帧 ";

                    //////////////////////////////////////////
                    if (m_recobj1[i].RemoteFlag == 0)
                    {
                        str2 += "数据: ";
                        byte len = (byte)(m_recobj1[i].DataLen % 9);
                        byte j = 0;
                        fixed (VCI_CAN_OBJ* m_recobj_2 = &m_recobj2[i])
                        {
                            if (j++ < len)
                                str2 += " " + System.Convert.ToString(m_recobj_2->Data[0], 16);
                            if (j++ < len)
                                str2 += " " + System.Convert.ToString(m_recobj_2->Data[1], 16);
                            if (j++ < len)
                                str2 += " " + System.Convert.ToString(m_recobj_2->Data[2], 16);
                            if (j++ < len)
                                str2 += " " + System.Convert.ToString(m_recobj_2->Data[3], 16);
                            if (j++ < len)
                                str2 += " " + System.Convert.ToString(m_recobj_2->Data[4], 16);
                            if (j++ < len)
                                str2 += " " + System.Convert.ToString(m_recobj_2->Data[5], 16);
                            if (j++ < len)
                                str2 += " " + System.Convert.ToString(m_recobj_2->Data[6], 16);
                            if (j++ < len)
                                str2 += " " + System.Convert.ToString(m_recobj_2->Data[7], 16);
                        }
                    }
                    listBox_Info2.Items.Add(str2);//显示信息框中显示收到的字符串
                    listBox_Info2.SelectedIndex = listBox_Info2.Items.Count - 1;//选择最新出现的一行，selectedIndex是document.form.site的当前选择项的索引值，从0开始从上往下依次递增，没选中是-1

                }
                flag_can = 2;//标志置位
            }
            else if (flag_can == 2)
            {
                res1 = VCI_Receive(m_devtype, m_devind, m_canind1, ref m_recobj1[0], 1000, 100);//第1路CAN的接收函数
                for (UInt32 i = 0; i < res1; i++)
                {
                    //VCI_CAN_OBJ obj = (VCI_CAN_OBJ)Marshal.PtrToStructure((IntPtr)((UInt32)pt + i * Marshal.SizeOf(typeof(VCI_CAN_OBJ))), typeof(VCI_CAN_OBJ));

                    str = "接收到数据: ";
                    str += "  帧ID:0x" + System.Convert.ToString(m_recobj1[i].ID, 16);
                    str += "  帧格式:";
                    if (m_recobj1[i].RemoteFlag == 0)
                        str += "数据帧 ";
                    else
                        str += "远程帧 ";
                    if (m_recobj1[i].ExternFlag == 0)
                        str += "标准帧 ";
                    else
                        str += "扩展帧 ";

                    //////////////////////////////////////////
                    if (m_recobj1[i].RemoteFlag == 0)
                    {
                        str += "数据: ";
                        byte len = (byte)(m_recobj1[i].DataLen % 9);
                        byte j = 0;
                        fixed (VCI_CAN_OBJ* m_recobj_1 = &m_recobj1[i])
                        {
                            if (j++ < len)
                                str += " " + System.Convert.ToString(m_recobj_1->Data[0], 16);
                            if (j++ < len)
                                str += " " + System.Convert.ToString(m_recobj_1->Data[1], 16);
                            if (j++ < len)
                                str += " " + System.Convert.ToString(m_recobj_1->Data[2], 16);
                            if (j++ < len)
                                str += " " + System.Convert.ToString(m_recobj_1->Data[3], 16);
                            if (j++ < len)
                                str += " " + System.Convert.ToString(m_recobj_1->Data[4], 16);
                            if (j++ < len)
                                str += " " + System.Convert.ToString(m_recobj_1->Data[5], 16);
                            if (j++ < len)
                                str += " " + System.Convert.ToString(m_recobj_1->Data[6], 16);
                            if (j++ < len)
                                str += " " + System.Convert.ToString(m_recobj_1->Data[7], 16);
                        }
                    }

                    listBox_Info1.Items.Add(str);//显示信息框中显示收到的字符串
                    listBox_Info1.SelectedIndex = listBox_Info1.Items.Count - 1;//选择最新出现的一行，selectedIndex是document.form.site的当前选择项的索引值，从0开始从上往下依次递增，没选中是-1
                }
                flag_can = 1;//标志置位
            }
        }
    }
}
